var username = prompt("Enter Your Name");
var my_name = "Mashood Hussain";
var message = "Hello World";

alert(message);

//Student bio data 

name = "Jhone Doe";
age = 18;
course = " Certified mobile and web";

alert(name);
alert(age);
alert(course);

// script display pizza
var var1 = "pizza";
var var2 = "pizz";
var var3 = "piz";
var var4 = "pi";
alert(var1 + "\n" + var2 + "\n" + var3 + "\n" + var4 );
 // email

 email = "mashoodhussain100@gmail.com";

 alert("My email is" + email);
 
 //book
 book ="A smarter way to learn JavaScript";
 
 alert ("I'm tring to learn new book which is " + book);

 // write on page

 document.write(" Write a script to display this in browser through JS");

 //
 var end = "“▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬”"
 alert(end);
 