var age = 18;
alert("I'm " + age + " year old")

// page visit

var n = 12;
alert("You visit this site " + n + " times");

//birth year

var birth_year = 2001;

document.write("My Birth Year is " + birth_year +" <br>" + "Data type of My birthday declearation is Number");

// xyz store

var name = "Jone Doe"
var quantity = 34;
var product = "Shirts"

document.write("<br> <br> <b>"+ name + "<b> ordered <b> "+quantity+"<b> <b> "+product+ " <b> from xyz.com"  );