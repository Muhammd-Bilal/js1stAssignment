//question 1
var var1 = 23 , var2 = 212 , var3 = 34;
// quwstion 2

// illegal variable

// var 1stname ="";
// var brainly-in ="";
// var @gmail = "";
// var 2nd = "";
// var %per = "";


// legal variable

var $dollar = 34;
var first_name ="Mashood";
var _user = "";
var buyer = "Student";

document.write("<h2> Rule of nameing  javascript <h2>");

document.write("<h4> Variables must begin with a Number, $ or_. For example $name, _name or name <br> Variable names can only contain number, $,alphabate and _.For example $my_1stVariable");
document.write("<br> Variable name should be case sensitive <br> js variable should not be js key words")