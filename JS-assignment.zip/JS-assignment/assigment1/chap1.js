alert("Error "+ "\n \n " +"Please Enter Correct Password");
alert("Hello user happy coding"+ "\n \n " +"welcome to Js world");
alert("welcome to js world");
alert("Hello user happy coding"+ "\n \n " +"welcome back");

confirm("Prevent this page from creating additional dialogs");